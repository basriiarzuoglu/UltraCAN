import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Window
import QtQuick.Dialogs

import RbfCAN.Theme
import RbfCAN.Routing
import RbfCAN.Components
import RbfCAN.Core

/*!
    Application shell.

    Responsibilities and nothing more:
      - own the window chrome and the global layout (sidebar | content | status bar)
      - bind the Sidebar to the Navigation singleton
      - keep every page alive and show one of them

    All module behaviour lives inside the views themselves.
*/
ApplicationWindow {
    id: window

    width: 1440
    height: 900
    minimumWidth: 960
    minimumHeight: 600
    visible: true
    title: qsTr("RbfCAN - %1").arg(Navigation.currentRoute.title)

    /*! Outcome of the last session export/import, shown in the status bar and
        cleared on a timer - a message that never goes away stops being read. */
    property string sessionMessage: ""
    onSessionMessageChanged: if (window.sessionMessage.length > 0) sessionMessageTimer.restart()
    Timer {
        id: sessionMessageTimer
        interval: 6000
        onTriggered: window.sessionMessage = ""
    }
    color: Theme.background

    /*!
        Frameless, but NOT featureless.

        FramelessWindowHint alone removes the native caption AND the window
        styles that hang off it, which on Windows quietly costs the taskbar
        minimise/restore animation, Aero Snap and the Alt+Space system menu -
        the frame is gone, so WS_MINIMIZEBOX / WS_MAXIMIZEBOX / WS_SYSMENU go
        with it. Asking for the button hints explicitly puts those styles back
        without bringing the caption back: Qt maps each hint to its Win32
        style, and the shell then treats this like any other resizable window.

        The drawing is ours; the window management stays the platform's.
    */
    flags: Qt.Window
         | Qt.FramelessWindowHint
         | Qt.WindowMinimizeButtonHint
         | Qt.WindowMaximizeButtonHint
         | Qt.WindowSystemMenuHint

    // Frameless windows lose edge resizing with the frame; this hands it back
    // to the OS. Extracted to a component so the setup dialog gets the exact
    // same behaviour rather than a second copy that drifts. See its own doc.
    WindowResizeBorders {}

    // Global keyboard routing: Ctrl+1..6 jump straight to a module.
    Repeater {
        model: Navigation.routes
        Item {
            required property int index
            Shortcut {
                sequence: "Ctrl+" + (index + 1)
                onActivated: Navigation.navigateToIndex(index)
            }
        }
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        // ------------------------------------------------------- title bar
        TitleBar {
            Layout.fillWidth: true
            Layout.preferredHeight: Theme.titleBarHeight
            // One source of truth for the caption: the bar, the taskbar button
            // and Alt+Tab all read window.title.
            title: window.title
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            // -------------------------------------------------- navigation
            Sidebar {
                id: sidebar
                Layout.fillHeight: true
                // Auto-collapse on narrow windows; the user can still toggle manually.
                collapsed: window.width < 1100
                model: Navigation.routes
                currentIndex: Navigation.currentIndex
                onRouteSelected: (index) => Navigation.navigateToIndex(index)
                onExportRequested: configExportDialog.open()
                onImportRequested: configImportDialog.open()
            }

            // ----------------------------------------------- content area
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                color: Theme.surface
                clip: true

                // ------------------------------------------------- the pages
                //
                // This was one Loader with `sourceComponent:
                // Navigation.currentRoute.page`, and that single binding was
                // the state-loss bug: assigning a Loader a new
                // sourceComponent DESTROYS the item it is holding. Leaving
                // Graph Plot therefore deleted every ChartView, every series
                // and the whole pane tree, and coming back built a fresh page
                // that had never heard of them. Nothing was "reset" - the page
                // was a different object each time.
                //
                // A StackLayout instead: one child per route, all of them
                // alive, only `visible` changing as the user navigates. The
                // Loader per child survives because its `active` LATCHES - a
                // route is instantiated the first time it is visited and never
                // torn down, so start-up still costs one page rather than five.
                //
                // Verified: a Repeater inside a StackLayout is not counted as
                // one of its pages (StackLayout.count == the delegate count,
                // and StackLayout.index is the route index), so currentIndex
                // lines up with Navigation.currentIndex with no offset.
                StackLayout {
                    id: pageStack
                    anchors.fill: parent
                    currentIndex: Navigation.currentIndex

                    Repeater {
                        model: Navigation.routes

                        delegate: Loader {
                            id: pageHost

                            required property int index
                            required property var modelData

                            readonly property bool isCurrent: pageHost.index === Navigation.currentIndex

                            /*! Latches true on first visit and is never
                                cleared - that one-way door is the whole fix.
                                A plain `active: isCurrent` would deactivate on
                                the way out, which destroys the item exactly
                                like the old Loader did.

                                Routes marked eager start out latched: they hold
                                state the rest of the app queries whether or not
                                the user has been there. See NavRoute::eager. */
                            property bool visited: false
                            onIsCurrentChanged: if (pageHost.isCurrent) pageHost.visited = true
                            Component.onCompleted: {
                                if (pageHost.isCurrent || pageHost.modelData.eager)
                                    pageHost.visited = true
                            }

                            active: pageHost.visited
                            asynchronous: true
                            sourceComponent: pageHost.modelData.page

                            // First paint of a page still fades in. There is no
                            // cross-page fade any more: with both pages alive,
                            // StackLayout swaps `visible` in one frame and
                            // there is nothing left to hide.
                            opacity: pageHost.status === Loader.Ready ? 1 : 0
                            Behavior on opacity { NumberAnimation { duration: Theme.durationNormal } }
                        }
                    }
                }

                BusyIndicator {
                    anchors.centerIn: parent
                    // Only ever seen on a route's FIRST visit; afterwards the
                    // page is already built and the switch is instant.
                    running: {
                        const item = pageStack.currentIndex >= 0
                                  && pageStack.currentIndex < pageStack.count
                                   ? pageStack.itemAt(pageStack.currentIndex) : null
                        return item !== null && item.status === Loader.Loading
                    }
                    visible: running
                }
            }
        }

        // ------------------------------------------------- session files
        //
        // The shell owns these, not the Sidebar: Sidebar is model-agnostic by
        // design and never imports RbfCAN.Core.
        //
        // Note what is NOT here - any knowledge of the graph workspace. The
        // Graph Plot page answers ConfigManager's graphStateRequested /
        // graphStateRestored signals itself, which is why that page is marked
        // eager in Navigation: a page that was never opened cannot answer, and
        // the export would silently save no workspace at all.
        FileDialog {
            id: configExportDialog
            title: qsTr("Save session")
            fileMode: FileDialog.SaveFile
            defaultSuffix: "rbfc"
            nameFilters: [ qsTr("RbfCAN session (*.rbfc)"), qsTr("JSON (*.json)"),
                           qsTr("All files (*)") ]
            onAccepted: {
                ConfigManager.exportConfig(selectedFile)
                window.sessionMessage = ConfigManager.lastMessage
            }
        }

        FileDialog {
            id: configImportDialog
            title: qsTr("Open session")
            fileMode: FileDialog.OpenFile
            nameFilters: [ qsTr("RbfCAN session (*.rbfc *.json)"), qsTr("All files (*)") ]
            onAccepted: {
                ConfigManager.importConfig(selectedFile)
                window.sessionMessage = ConfigManager.lastMessage
            }
        }

        // ------------------------------------------------------ status bar
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: Theme.statusBarHeight
            color: Theme.panel

            Rectangle { width: parent.width; height: 1; color: Theme.border }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: Theme.spacingMd
                anchors.rightMargin: Theme.spacingMd
                spacing: Theme.spacingLg

                // -- bus state: click to open the connection panel
                Rectangle {
                    id: busIndicator

                    Layout.preferredHeight: Theme.statusBarHeight - 6
                    Layout.preferredWidth: busRow.implicitWidth + Theme.spacingSm
                    radius: Theme.radiusSm
                    color: busMouse.containsMouse ? Theme.panelElevated : "transparent"

                    RowLayout {
                        id: busRow
                        anchors.centerIn: parent
                        spacing: Theme.spacingSm

                        Rectangle {
                            width: 8; height: 8; radius: 4
                            color: {
                                switch (CanBusManager.connectionState) {
                                case CanBusManager.Connected:  return Theme.success
                                case CanBusManager.Connecting: return Theme.warning
                                case CanBusManager.Closing:    return Theme.warning
                                default: return CanBusManager.simulating ? Theme.accentAlt
                                                                         : Theme.textDisabled
                                }
                            }
                        }
                        Label {
                            text: qsTr("Bus: %1").arg(CanBusManager.busStatusText)
                            color: Theme.textSecondary
                            font.family: Theme.fontFamily
                            font.pixelSize: Theme.fontSizeSm
                        }
                        Label {
                            text: "▴"
                            color: Theme.textDisabled
                            font.pixelSize: Theme.fontSizeSm
                        }
                    }

                    MouseArea {
                        id: busMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: busPanel.opened ? busPanel.close() : busPanel.open()
                    }

                    // -- connection panel -------------------------------------
                    Popup {
                        id: busPanel

                        y: -height - Theme.spacingSm
                        width: 340
                        padding: Theme.spacingMd
                        modal: false
                        focus: true
                        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutsideParent

                        background: Rectangle {
                            color: Theme.panel
                            radius: Theme.radiusMd
                            border.width: 1
                            border.color: Theme.border
                        }

                        /*! True once the remembered selection has been applied.
                            A later plugin change must not drag the previous
                            plugin's interface name along with it. */
                        property bool restored: false

                        // Enumerating plugins/interfaces hits the Qt plugin
                        // loader, so it is done when the panel opens, not in a
                        // binding that would re-run on every repaint.
                        function refresh() {
                            const plugins = CanBusManager.availablePlugins()
                            pluginBox.model = plugins
                            if (pluginBox.currentIndex < 0 && plugins.length > 0) {
                                // Order of preference: what worked last time,
                                // then what Qt suggests, then whatever is first.
                                const remembered = plugins.indexOf(SettingsManager.canPlugin)
                                const preferred = plugins.indexOf(CanBusManager.preferredPlugin())
                                pluginBox.currentIndex = remembered >= 0 ? remembered
                                                       : (preferred >= 0 ? preferred : 0)
                            }
                            refreshInterfaces()

                            // A bitrate is a plain number rather than an
                            // enumeration of what is plugged in, so it restores
                            // unconditionally.
                            if (!busPanel.restored) {
                                const rateIndex = CanBusManager.standardBitrates()
                                                  .indexOf(SettingsManager.bitrate)
                                if (rateIndex >= 0)
                                    bitrateBox.currentIndex = rateIndex
                            }
                            busPanel.restored = true
                        }

                        function refreshInterfaces() {
                            const interfaces = CanBusManager.availableInterfaces(pluginBox.currentText)
                            interfaceBox.model = interfaces
                            if (interfaceBox.count === 0)
                                return
                            if (!busPanel.restored) {
                                const remembered = interfaces.indexOf(SettingsManager.canInterface)
                                interfaceBox.currentIndex = remembered >= 0 ? remembered : 0
                            } else if (interfaceBox.currentIndex < 0) {
                                interfaceBox.currentIndex = 0
                            }
                        }

                        onOpened: refresh()

                        Connections {
                            target: CanBusManager
                            // The C++ side re-queries QCanBus on every call
                            // anyway; this just gives the explicit Refresh
                            // button below something to fire so a newly
                            // plugged-in analyzer shows up without closing
                            // and reopening the panel.
                            function onInterfacesRefreshed() { busPanel.refresh() }
                        }

                        ColumnLayout {
                            width: parent.width
                            spacing: Theme.spacingSm

                            Label {
                                text: qsTr("CAN INTERFACE")
                                color: Theme.textDisabled
                                font.family: Theme.fontFamily
                                font.pixelSize: Theme.fontSizeSm
                                font.letterSpacing: 1.1
                            }

                            PropertyField {
                                label: qsTr("Plugin")
                                labelWidth: 70
                                horizontalMargin: 0
                                ThemedComboBox {
                                    id: pluginBox
                                    Layout.fillWidth: true
                                    enabled: !CanBusManager.connected
                                    onActivated: busPanel.refreshInterfaces()
                                }
                            }

                            PropertyField {
                                label: qsTr("Interface")
                                labelWidth: 70
                                horizontalMargin: 0

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: Theme.spacingXs

                                    ThemedComboBox {
                                        id: interfaceBox
                                        Layout.fillWidth: true
                                        enabled: !CanBusManager.connected
                                    }

                                    ToolbarButton {
                                        // Icon-only: glyph with no text, so it
                                        // stays compact next to the combo box
                                        // rather than competing with it for
                                        // width. Left at its natural implicit
                                        // size (no forced square) so the
                                        // background Control machinery centres
                                        // the glyph correctly - overriding
                                        // implicitWidth here would leave the
                                        // RowLayout inside narrower than the
                                        // button and glyph left-hugged.
                                        glyph: "⟳"
                                        leftPadding: Theme.spacingSm
                                        rightPadding: Theme.spacingSm
                                        enabled: !CanBusManager.connected
                                        onClicked: CanBusManager.refreshInterfaces()

                                        ToolTip.visible: hovered
                                        ToolTip.delay: 400
                                        ToolTip.text: qsTr("Rescan for connected CAN interfaces")
                                    }
                                }
                            }

                            PropertyField {
                                label: qsTr("Bitrate")
                                labelWidth: 70
                                horizontalMargin: 0
                                suffix: qsTr("bit/s")
                                ThemedComboBox {
                                    id: bitrateBox
                                    Layout.fillWidth: true
                                    enabled: !CanBusManager.connected
                                    model: CanBusManager.standardBitrates()
                                    // Fallback only; busPanel.refresh() replaces
                                    // this with the remembered rate on first open.
                                    currentIndex: 2          // 500 kbit/s
                                }
                            }

                            PropertyField {
                                label: qsTr("Simulator")
                                labelWidth: 70
                                horizontalMargin: 0
                                ThemedSwitch {
                                    enabled: !CanBusManager.connected
                                    checked: CanBusManager.simulating
                                    text: checked ? qsTr("Generating traffic") : qsTr("Off")
                                    onToggled: {
                                        const wanted = checked
                                        checked = Qt.binding(function() { return CanBusManager.simulating })
                                        CanBusManager.simulating = wanted
                                    }
                                }
                            }

                            Label {
                                Layout.fillWidth: true
                                text: qsTr("Remembered once the bus actually connects.")
                                color: Theme.textDisabled
                                font.family: Theme.fontFamily
                                font.pixelSize: Theme.fontSizeSm
                                visible: !CanBusManager.connected
                                ToolTip.visible: hover.hovered
                                ToolTip.text: SettingsManager.configFilePath
                                HoverHandler { id: hover }
                            }

                            Label {
                                Layout.fillWidth: true
                                Layout.maximumWidth: busPanel.availableWidth
                                visible: CanBusManager.lastError.length > 0
                                text: CanBusManager.lastError
                                color: Theme.error
                                font.family: Theme.fontFamily
                                font.pixelSize: Theme.fontSizeSm
                                // WrapAnywhere, not WordWrap: driver messages can be
                                // one unbroken run of characters, which WordWrap
                                // cannot break - it just overflows the popup.
                                wrapMode: Text.WrapAnywhere
                                maximumLineCount: 3
                                elide: Text.ElideRight
                            }

                            RowLayout {
                                Layout.fillWidth: true
                                Layout.topMargin: Theme.spacingXs
                                spacing: Theme.spacingSm

                                Label {
                                    Layout.fillWidth: true
                                    text: qsTr("%1 error frames").arg(CanBusManager.errorFrameCount)
                                    visible: CanBusManager.errorFrameCount > 0
                                    color: Theme.warning
                                    font.family: Theme.fontFamily
                                    font.pixelSize: Theme.fontSizeSm
                                }
                                Item { Layout.fillWidth: true; visible: CanBusManager.errorFrameCount === 0 }

                                ToolbarButton {
                                    text: qsTr("Disconnect")
                                    destructive: true
                                    visible: CanBusManager.connected
                                             || CanBusManager.connectionState === CanBusManager.Connecting
                                    onClicked: CanBusManager.disconnectBus()
                                }
                                ToolbarButton {
                                    text: qsTr("Connect")
                                    primary: true
                                    visible: !CanBusManager.connected
                                             && CanBusManager.connectionState !== CanBusManager.Connecting
                                    enabled: interfaceBox.count > 0
                                    onClicked: CanBusManager.connectBus(pluginBox.currentText,
                                                                        interfaceBox.currentText,
                                                                        Number(bitrateBox.currentText))
                                }
                            }
                        }
                    }
                }

                Label {
                    text: window.sessionMessage
                    visible: window.sessionMessage.length > 0
                    color: ConfigManager.lastError.length > 0 ? Theme.error : Theme.textSecondary
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontSizeSm
                    elide: Text.ElideRight
                    Layout.maximumWidth: 420
                }

                Item { Layout.fillWidth: true }

                Label {
                    text: Navigation.currentRoute.title
                    color: Theme.textDisabled
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontSizeSm
                }
            }
        }
    }
}
